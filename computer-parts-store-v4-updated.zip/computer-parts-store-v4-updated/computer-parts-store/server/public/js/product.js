/* =========================
   صفحه‌ی محصول
========================= */

const productId = new URLSearchParams(window.location.search).get("id");

let galleryImages = [];
let currentImageIndex = 0;

/* =========================
   عناصر DOM
========================= */

const loadingEl = document.getElementById("productLoading");
const errorEl = document.getElementById("productError");
const pageEl = document.getElementById("productPage");

const mainImageEl = document.getElementById("galleryMainImage");
const placeholderEl = document.getElementById("galleryPlaceholder");
const thumbsEl = document.getElementById("galleryThumbs");

const lightboxEl = document.getElementById("lightbox");
const lightboxImageEl = document.getElementById("lightboxImage");

/* =========================
   نمایش خطا
========================= */

function showError(message) {
  loadingEl.hidden = true;
  pageEl.hidden = true;
  errorEl.hidden = false;
  errorEl.textContent = message;
}

/* =========================
   گالری عکس
========================= */

function selectImage(index) {
  if (galleryImages.length === 0) return;

  currentImageIndex = (index + galleryImages.length) % galleryImages.length;
  const image = galleryImages[currentImageIndex];

  mainImageEl.src = image.url;
  mainImageEl.alt = image.alt || "";
  mainImageEl.hidden = false;
  placeholderEl.hidden = true;

  thumbsEl.querySelectorAll(".gallery-thumb").forEach((thumb, i) => {
    thumb.classList.toggle("active", i === currentImageIndex);
    thumb.setAttribute("aria-current", i === currentImageIndex ? "true" : "false");
  });

  if (!lightboxEl.hidden) {
    lightboxImageEl.src = image.url;
    lightboxImageEl.alt = image.alt || "";
  }
}

function renderGallery(images, categoryIcon) {
  galleryImages = images || [];

  if (galleryImages.length === 0) {
    mainImageEl.hidden = true;
    placeholderEl.hidden = false;
    placeholderEl.textContent = categoryIcon || "📦";
    thumbsEl.hidden = true;
    return;
  }

  thumbsEl.innerHTML = "";

  // اگه فقط یک عکس هست، نوار بندانگشتی لازم نیست
  thumbsEl.hidden = galleryImages.length < 2;

  galleryImages.forEach((image, index) => {
    const thumb = document.createElement("button");
    thumb.type = "button";
    thumb.className = "gallery-thumb";
    thumb.innerHTML = `<img src="${escapeHtml(image.url)}" alt="${escapeHtml(image.alt || "")}">`;
    thumb.addEventListener("click", () => selectImage(index));
    thumbsEl.appendChild(thumb);
  });

  selectImage(0);
}

/* =========================
   نمایش بزرگ عکس (Lightbox)
========================= */

function openLightbox() {
  if (galleryImages.length === 0) return;

  lightboxEl.hidden = false;
  lightboxImageEl.src = galleryImages[currentImageIndex].url;
  lightboxImageEl.alt = galleryImages[currentImageIndex].alt || "";
  document.body.style.overflow = "hidden";
}

function closeLightbox() {
  lightboxEl.hidden = true;
  document.body.style.overflow = "";
}

mainImageEl.addEventListener("click", openLightbox);
document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
document.getElementById("lightboxPrev").addEventListener("click", () => selectImage(currentImageIndex - 1));
document.getElementById("lightboxNext").addEventListener("click", () => selectImage(currentImageIndex + 1));

lightboxEl.addEventListener("click", (event) => {
  if (event.target === lightboxEl) closeLightbox();
});

document.addEventListener("keydown", (event) => {
  if (lightboxEl.hidden) return;

  if (event.key === "Escape") closeLightbox();
  if (event.key === "ArrowRight") selectImage(currentImageIndex - 1);
  if (event.key === "ArrowLeft") selectImage(currentImageIndex + 1);
});

/* =========================
   مشخصات فنی
========================= */

function renderSpecs(specGroups) {
  const section = document.getElementById("specsSection");
  const container = document.getElementById("specGroups");

  if (!specGroups || specGroups.length === 0) {
    section.hidden = true;
    return;
  }

  container.innerHTML = "";

  specGroups.forEach((group) => {
    if (!group.items || group.items.length === 0) return;

    const groupEl = document.createElement("div");
    groupEl.className = "spec-group";

    const rows = group.items
      .map(
        (item) => `
          <div class="spec-row">
            <span class="spec-label">${escapeHtml(item.label)}</span>
            <span class="spec-value">${escapeHtml(item.value || "—")}</span>
          </div>`
      )
      .join("");

    groupEl.innerHTML = `
      ${group.title ? `<h3 class="spec-group-title">${escapeHtml(group.title)}</h3>` : ""}
      <div class="spec-rows">${rows}</div>
    `;

    container.appendChild(groupEl);
  });

  section.hidden = container.children.length === 0;
}

/* =========================
   توضیحات کامل
   متن ساده‌ست؛ فقط خط‌های جدید رو به پاراگراف تبدیل می‌کنیم.
========================= */

function renderLongDescription(text) {
  const section = document.getElementById("descriptionSection");
  const container = document.getElementById("productLongDesc");

  if (!text || !text.trim()) {
    section.hidden = true;
    return;
  }

  container.innerHTML = text
    .split(/\n\s*\n/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean)
    .map((paragraph) => `<p>${escapeHtml(paragraph).replace(/\n/g, "<br>")}</p>`)
    .join("");

  section.hidden = false;
}

/* =========================
   بارگذاری محصول
========================= */

async function loadProduct() {
  if (!productId || !/^\d+$/.test(productId)) {
    showError("آدرس محصول درست نیست.");
    return;
  }

  try {
    const [{ product }, { categories }] = await Promise.all([
      apiRequest(`/api/products/${productId}`),
      apiRequest("/api/categories"),
    ]);

    const categoryInfo = categories[product.category] || {};

    document.title = `${product.name} | TechZone`;

    // مسیر صفحه
    const breadcrumbCategory = document.getElementById("breadcrumbCategory");
    breadcrumbCategory.textContent = categoryInfo.name || product.category;
    breadcrumbCategory.href = `/pages/category.html?cat=${encodeURIComponent(product.category)}`;
    document.getElementById("breadcrumbName").textContent = product.name;

    // عنوان و وضعیت
    document.getElementById("productName").textContent = product.name;

    const conditionEl = document.getElementById("productCondition");
    conditionEl.textContent = product.condition === "new" ? "نو" : "دست دوم";
    conditionEl.classList.add(product.condition);

    // برند و مدل و دسته‌بندی
    const metaParts = [];
    if (product.brand) metaParts.push(product.brand);
    if (product.model) metaParts.push(product.model);
    if (categoryInfo.name) metaParts.push(categoryInfo.name);
    document.getElementById("productMeta").textContent = metaParts.join(" • ");

    // توضیح کوتاه
    const shortDescEl = document.getElementById("productShortDesc");
    shortDescEl.textContent = product.description || "";
    shortDescEl.hidden = !product.description;

    // قیمت
    document.getElementById("productPrice").textContent =
      Number(product.price).toLocaleString("fa-IR");

    // موجودی
    const stockEl = document.getElementById("productStock");
    const stock = Number(product.stock);
    const addBtn = document.getElementById("addToCartBtn");

    if (stock > 0) {
      stockEl.textContent = stock <= 3 ? `فقط ${stock} عدد در انبار` : "موجود در انبار";
      stockEl.className = "purchase-stock in-stock";
    } else {
      stockEl.textContent = "ناموجود";
      stockEl.className = "purchase-stock out-of-stock";
      addBtn.disabled = true;
      addBtn.textContent = "ناموجود";
    }

    // گارانتی
    if (product.warranty) {
      const warrantyEl = document.getElementById("productWarranty");
      warrantyEl.textContent = `🛡️ ${product.warranty}`;
      warrantyEl.hidden = false;
    }

    renderGallery(product.images, categoryInfo.icon);
    renderLongDescription(product.long_description);
    renderSpecs(product.specGroups);

    loadingEl.hidden = true;
    pageEl.hidden = false;
  } catch (err) {
    showError(
      err.message === "محصول پیدا نشد"
        ? "این محصول وجود نداره یا حذف شده."
        : "دریافت اطلاعات محصول انجام نشد: " + err.message
    );
  }
}

/* =========================
   سبد خرید
========================= */

let cartCount = 0;

document.getElementById("addToCartBtn").addEventListener("click", function () {
  cartCount++;
  const cartCountElement = document.getElementById("cartCount");
  if (cartCountElement) cartCountElement.textContent = cartCount;

  this.textContent = "به سبد اضافه شد";
  setTimeout(() => {
    this.textContent = "افزودن به سبد خرید";
  }, 1500);
});

loadProduct();
