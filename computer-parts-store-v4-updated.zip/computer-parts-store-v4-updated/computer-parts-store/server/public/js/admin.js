/* =========================
   پنل مدیریت - متصل به API واقعی
========================= */

let products = [];
let categoriesMap = {};
let editingId = null; // اگه null باشه یعنی حالت "افزودن"، وگرنه یعنی حالت "ویرایش"

// وضعیت فرم: عکس‌ها و گروه‌های ویژگی که هنوز ذخیره نشدن
let formImages = [];      // [{ url, alt }]
let formSpecGroups = [];  // [{ title, items: [{ label, value }] }]

/* =========================
   عناصر DOM
========================= */

const productTableBody = document.getElementById("productTableBody");
const addProductBtn = document.querySelector(".add-product-btn");
const logoutBtn = document.getElementById("logoutBtn");

const modalOverlay = document.getElementById("productModalOverlay");
const modalTitle = document.getElementById("modalTitle");
const productForm = document.getElementById("productForm");
const saveBtn = document.getElementById("modalSaveBtn");

const productNameInput = document.getElementById("productNameInput");
const productCategoryInput = document.getElementById("productCategoryInput");
const productPriceInput = document.getElementById("productPriceInput");
const productStockInput = document.getElementById("productStockInput");
const productBrandInput = document.getElementById("productBrandInput");
const productModelInput = document.getElementById("productModelInput");
const productConditionInput = document.getElementById("productConditionInput");
const productWarrantyInput = document.getElementById("productWarrantyInput");
const productDescInput = document.getElementById("productDescInput");
const productLongDescInput = document.getElementById("productLongDescInput");

const imageDropzone = document.getElementById("imageDropzone");
const imageFileInput = document.getElementById("imageFileInput");
const imagePickBtn = document.getElementById("imagePickBtn");
const imageListEl = document.getElementById("imageList");
const imageHint = document.getElementById("imageHint");

const specGroupListEl = document.getElementById("specGroupList");
const addSpecGroupBtn = document.getElementById("addSpecGroupBtn");

const modalCloseBtn = document.getElementById("modalCloseBtn");
const modalCancelBtn = document.getElementById("modalCancelBtn");

/* =========================
   بارگذاری اولیه صفحه
========================= */

async function init() {
  const loggedIn = await checkAuth();

  if (!loggedIn) {
    window.location.href = "/pages/login.html";
    return;
  }

  await loadCategories();
  await loadProducts();
}

async function loadCategories() {
  const data = await apiRequest("/api/categories");
  categoriesMap = data.categories;

  productCategoryInput.innerHTML = Object.entries(categoriesMap)
    .map(
      ([key, cat]) =>
        `<option value="${key}">${escapeHtml(cat.name)} (${escapeHtml(cat.subtitle)})</option>`
    )
    .join("");
}

async function loadProducts() {
  const data = await apiRequest("/api/products");
  products = data.products;
  renderProducts();
}

/* =========================
   رندر جدول محصولات
========================= */

function renderProducts() {
  const productCountStat = document.getElementById("productCountStat");
  if (productCountStat) productCountStat.textContent = products.length;

  productTableBody.innerHTML = "";

  if (products.length === 0) {
    productTableBody.innerHTML = `<div class="table-row"><span>هنوز محصولی اضافه نشده</span></div>`;
    return;
  }

  products.forEach(function (product) {
    const row = document.createElement("div");
    row.className = "table-row";

    const categoryName = categoriesMap[product.category]?.name || product.category;

    row.innerHTML = `
      <span>${escapeHtml(product.name)}</span>
      <span>${escapeHtml(categoryName)}</span>
      <span>${Number(product.price).toLocaleString("fa-IR")} تومان</span>
      <span>${escapeHtml(product.stock)}</span>
      <span>
        <a class="view-btn" href="/pages/product.html?id=${product.id}" target="_blank">مشاهده</a>
        <button class="edit-btn" data-id="${product.id}">ویرایش</button>
        <button class="delete-btn" data-id="${product.id}">حذف</button>
      </span>
    `;

    productTableBody.appendChild(row);
  });
}

/* =========================================================
   عکس‌ها
========================================================= */

function renderImageList() {
  imageListEl.innerHTML = "";
  imageHint.hidden = formImages.length === 0;

  formImages.forEach((image, index) => {
    const item = document.createElement("div");
    item.className = "image-item";

    item.innerHTML = `
      <img src="${escapeHtml(image.url)}" alt="">
      ${index === 0 ? '<span class="image-badge">عکس اصلی</span>' : ""}
      <div class="image-item-actions">
        <button type="button" class="image-move" data-dir="-1" data-index="${index}"
                title="انتقال به قبل" ${index === 0 ? "disabled" : ""}>→</button>
        <button type="button" class="image-move" data-dir="1" data-index="${index}"
                title="انتقال به بعد" ${index === formImages.length - 1 ? "disabled" : ""}>←</button>
        <button type="button" class="image-remove" data-index="${index}" title="حذف عکس">حذف</button>
      </div>
    `;

    imageListEl.appendChild(item);
  });
}

imageListEl.addEventListener("click", function (event) {
  const moveBtn = event.target.closest(".image-move");
  const removeBtn = event.target.closest(".image-remove");

  if (moveBtn) {
    const index = Number(moveBtn.dataset.index);
    const target = index + Number(moveBtn.dataset.dir);

    if (target < 0 || target >= formImages.length) return;

    [formImages[index], formImages[target]] = [formImages[target], formImages[index]];
    renderImageList();
  }

  if (removeBtn) {
    formImages.splice(Number(removeBtn.dataset.index), 1);
    renderImageList();
  }
});

// آپلود یک عکس: بدنه‌ی درخواست خود بایت‌های فایله
async function uploadImageFile(file) {
  const res = await fetch("/api/uploads", {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": file.type || "application/octet-stream",
      "X-CSRF-Token": getCsrfToken(),
    },
    body: file,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `آپلود «${file.name}» انجام نشد`);
  }

  return data.url;
}

async function handleFiles(fileList) {
  const files = Array.from(fileList).filter((file) => file.type.startsWith("image/"));
  if (files.length === 0) return;

  imageDropzone.classList.add("uploading");
  const originalText = imageDropzone.querySelector("p").textContent;

  let uploaded = 0;
  const failures = [];

  for (const file of files) {
    imageDropzone.querySelector("p").textContent =
      `در حال آپلود ${uploaded + 1} از ${files.length}…`;

    try {
      const url = await uploadImageFile(file);
      formImages.push({ url, alt: "" });
      uploaded++;
      renderImageList();
    } catch (err) {
      failures.push(`${file.name}: ${err.message}`);
    }
  }

  imageDropzone.classList.remove("uploading");
  imageDropzone.querySelector("p").innerHTML =
    'عکس‌ها رو اینجا رها کن یا <button type="button" id="imagePickBtn" class="link-btn">انتخاب از سیستم</button>';
  document.getElementById("imagePickBtn").addEventListener("click", () => imageFileInput.click());

  if (failures.length > 0) {
    alert("بعضی عکس‌ها آپلود نشدن:\n" + failures.join("\n"));
  }
}

imagePickBtn.addEventListener("click", () => imageFileInput.click());

imageFileInput.addEventListener("change", function () {
  handleFiles(this.files);
  this.value = ""; // تا بشه همون فایل رو دوباره انتخاب کرد
});

["dragenter", "dragover"].forEach((eventName) => {
  imageDropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    imageDropzone.classList.add("dragover");
  });
});

["dragleave", "drop"].forEach((eventName) => {
  imageDropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    imageDropzone.classList.remove("dragover");
  });
});

imageDropzone.addEventListener("drop", (event) => {
  if (event.dataTransfer?.files) handleFiles(event.dataTransfer.files);
});

/* =========================================================
   گروه‌های ویژگی
========================================================= */

function renderSpecGroups() {
  specGroupListEl.innerHTML = "";

  formSpecGroups.forEach((group, groupIndex) => {
    const groupEl = document.createElement("div");
    groupEl.className = "spec-group-editor";

    const rows = group.items
      .map(
        (item, itemIndex) => `
        <div class="spec-row-editor">
          <input type="text" class="spec-label-input" placeholder="نام ویژگی (مثلاً تعداد هسته)"
                 value="${escapeHtml(item.label)}"
                 data-group="${groupIndex}" data-item="${itemIndex}">
          <input type="text" class="spec-value-input" placeholder="مقدار (مثلاً ۸ هسته)"
                 value="${escapeHtml(item.value)}"
                 data-group="${groupIndex}" data-item="${itemIndex}">
          <button type="button" class="spec-remove-row" data-group="${groupIndex}" data-item="${itemIndex}"
                  title="حذف این ویژگی">&times;</button>
        </div>`
      )
      .join("");

    groupEl.innerHTML = `
      <div class="spec-group-header">
        <input type="text" class="spec-group-title-input" placeholder="نام بخش (مثلاً مشخصات کلی)"
               value="${escapeHtml(group.title)}" data-group="${groupIndex}">
        <button type="button" class="spec-remove-group" data-group="${groupIndex}">حذف بخش</button>
      </div>

      <div class="spec-rows-editor">${rows}</div>

      <button type="button" class="spec-add-row secondary-btn" data-group="${groupIndex}">+ افزودن ویژگی</button>
    `;

    specGroupListEl.appendChild(groupEl);
  });
}

// مقادیر تایپ‌شده رو همون لحظه توی state ذخیره می‌کنیم تا با رندر دوباره از بین نرن
specGroupListEl.addEventListener("input", function (event) {
  const target = event.target;
  const groupIndex = Number(target.dataset.group);

  if (target.classList.contains("spec-group-title-input")) {
    formSpecGroups[groupIndex].title = target.value;
    return;
  }

  const itemIndex = Number(target.dataset.item);

  if (target.classList.contains("spec-label-input")) {
    formSpecGroups[groupIndex].items[itemIndex].label = target.value;
  }

  if (target.classList.contains("spec-value-input")) {
    formSpecGroups[groupIndex].items[itemIndex].value = target.value;
  }
});

specGroupListEl.addEventListener("click", function (event) {
  const addRowBtn = event.target.closest(".spec-add-row");
  const removeRowBtn = event.target.closest(".spec-remove-row");
  const removeGroupBtn = event.target.closest(".spec-remove-group");

  if (addRowBtn) {
    formSpecGroups[Number(addRowBtn.dataset.group)].items.push({ label: "", value: "" });
    renderSpecGroups();

    // فوکوس روی ویژگی تازه‌ساخته‌شده
    const inputs = specGroupListEl
      .querySelectorAll(`.spec-group-editor`)
      [Number(addRowBtn.dataset.group)].querySelectorAll(".spec-label-input");
    inputs[inputs.length - 1]?.focus();
  }

  if (removeRowBtn) {
    formSpecGroups[Number(removeRowBtn.dataset.group)].items.splice(
      Number(removeRowBtn.dataset.item),
      1
    );
    renderSpecGroups();
  }

  if (removeGroupBtn) {
    formSpecGroups.splice(Number(removeGroupBtn.dataset.group), 1);
    renderSpecGroups();
  }
});

addSpecGroupBtn.addEventListener("click", function () {
  formSpecGroups.push({ title: "", items: [{ label: "", value: "" }] });
  renderSpecGroups();

  const titleInputs = specGroupListEl.querySelectorAll(".spec-group-title-input");
  titleInputs[titleInputs.length - 1]?.focus();
});

/* =========================================================
   باز و بسته کردن مودال
========================================================= */

async function openModal(mode, product) {
  editingId = mode === "edit" ? product.id : null;

  modalTitle.textContent = mode === "edit" ? "ویرایش محصول" : "افزودن محصول";

  if (mode === "edit") {
    // لیست محصولات عکس و ویژگی کامل نداره، پس نسخه‌ی کامل رو می‌گیریم
    let full = product;
    try {
      const data = await apiRequest(`/api/products/${product.id}`);
      full = data.product;
    } catch (err) {
      alert("دریافت اطلاعات کامل محصول انجام نشد: " + err.message);
      return;
    }

    productNameInput.value = full.name;
    productCategoryInput.value = full.category;
    productPriceInput.value = full.price;
    productStockInput.value = full.stock;
    productBrandInput.value = full.brand || "";
    productModelInput.value = full.model || "";
    productConditionInput.value = full.condition || "new";
    productWarrantyInput.value = full.warranty || "";
    productDescInput.value = full.description || "";
    productLongDescInput.value = full.long_description || "";

    formImages = (full.images || []).map((img) => ({ url: img.url, alt: img.alt || "" }));
    formSpecGroups = (full.specGroups || []).map((group) => ({
      title: group.title || "",
      items: group.items.map((item) => ({ label: item.label, value: item.value })),
    }));
  } else {
    productForm.reset();
    productCategoryInput.value = Object.keys(categoriesMap)[0];
    productConditionInput.value = "new";

    formImages = [];
    formSpecGroups = [];
  }

  renderImageList();
  renderSpecGroups();

  modalOverlay.classList.add("active");
  productNameInput.focus();
}

function closeModal() {
  modalOverlay.classList.remove("active");
  productForm.reset();

  editingId = null;
  formImages = [];
  formSpecGroups = [];

  renderImageList();
  renderSpecGroups();
}

/* =========================
   رویدادها
========================= */

if (addProductBtn) {
  addProductBtn.addEventListener("click", function () {
    openModal("add");
  });
}

if (logoutBtn) {
  logoutBtn.addEventListener("click", async function () {
    await apiRequest("/api/logout", { method: "POST" });
    window.location.href = "/pages/login.html";
  });
}

if (modalCloseBtn) modalCloseBtn.addEventListener("click", closeModal);
if (modalCancelBtn) modalCancelBtn.addEventListener("click", closeModal);

if (modalOverlay) {
  modalOverlay.addEventListener("click", function (event) {
    if (event.target === modalOverlay) closeModal();
  });
}

if (productTableBody) {
  productTableBody.addEventListener("click", async function (event) {
    const id = Number(event.target.dataset.id);
    if (!id) return;

    if (event.target.classList.contains("edit-btn")) {
      const product = products.find((p) => p.id === id);
      if (product) await openModal("edit", product);
    }

    if (event.target.classList.contains("delete-btn")) {
      const confirmed = confirm("مطمئنی می‌خوای این محصول حذف بشه؟ عکس‌هاش هم پاک می‌شن.");
      if (!confirmed) return;

      try {
        await apiRequest(`/api/products/${id}`, { method: "DELETE" });
        await loadProducts();
      } catch (err) {
        alert(err.message);
      }
    }
  });
}

if (productForm) {
  productForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    // گروه‌های خالی (بدون هیچ ویژگی معتبر) رو نمی‌فرستیم
    const specGroups = formSpecGroups
      .map((group) => ({
        title: group.title.trim(),
        items: group.items.filter((item) => item.label.trim()),
      }))
      .filter((group) => group.items.length > 0);

    const payload = {
      name: productNameInput.value.trim(),
      category: productCategoryInput.value,
      price: Number(productPriceInput.value),
      stock: Number(productStockInput.value),
      condition: productConditionInput.value,
      brand: productBrandInput.value.trim(),
      model: productModelInput.value.trim(),
      warranty: productWarrantyInput.value.trim(),
      description: productDescInput.value.trim(),
      longDescription: productLongDescInput.value.trim(),
      images: formImages,
      specGroups,
    };

    saveBtn.disabled = true;
    saveBtn.textContent = "در حال ذخیره…";

    try {
      if (editingId === null) {
        await apiRequest("/api/products", {
          method: "POST",
          body: JSON.stringify(payload),
        });
      } else {
        await apiRequest(`/api/products/${editingId}`, {
          method: "PUT",
          body: JSON.stringify(payload),
        });
      }

      await loadProducts();
      closeModal();
    } catch (err) {
      alert(err.message);
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = "ذخیره";
    }
  });
}

init();
