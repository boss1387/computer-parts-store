/* =========================
   ورود کاربر عادی - متصل به API واقعی
========================= */

const accountLoginForm = document.getElementById("accountLoginForm");
const loginError = document.getElementById("loginError");

if (accountLoginForm) {
  accountLoginForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (loginError) loginError.textContent = "";

    try {
      const res = await fetch("/api/account/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || "ورود ناموفق بود");
      }

      window.location.href = "/pages/home.html";
    } catch (err) {
      if (loginError) {
        loginError.textContent = err.message;
      } else {
        alert(err.message);
      }
    }
  });
}
