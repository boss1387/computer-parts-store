/* =========================
   ثبت‌نام کاربر عادی - متصل به API واقعی
========================= */

const registerForm = document.getElementById("registerForm");
const registerError = document.getElementById("registerError");

if (registerForm) {
  registerForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (registerError) registerError.textContent = "";

    if (password !== confirmPassword) {
      if (registerError) registerError.textContent = "رمز عبور و تکرارش یکسان نیستن";
      return;
    }

    try {
      const res = await fetch("/api/account/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ firstName, lastName, email, password, confirmPassword }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || "ثبت‌نام ناموفق بود");
      }

      window.location.href = "/pages/home.html";
    } catch (err) {
      if (registerError) {
        registerError.textContent = err.message;
      } else {
        alert(err.message);
      }
    }
  });
}
