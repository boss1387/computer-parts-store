/* =========================
   صفحه اصلی - محصولات از API واقعی
========================= */

let cartCount = 0;

function addToCart() {
  cartCount++;
  const cartCountElement = document.getElementById("cartCount");
  if (cartCountElement) cartCountElement.textContent = cartCount;
}

const categoryIcons = {
  cpu: "🧠",
  gpu: "🎮",
  ram: "💾",
  storage: "💿",
  psu: "🔌",
  accessories: "⌨️",
};

function renderProductCard(product) {
  const conditionLabel = product.condition === "new" ? "نو" : "دست دوم";
  const icon = categoryIcons[product.category] || "📦";

  const card = document.createElement("article");
  card.className = "product-card";

  const imageContent = product.primaryImage
    ? `<img src="${escapeHtml(product.primaryImage)}" alt="${escapeHtml(product.name)}" loading="lazy">`
    : icon;

  card.innerHTML = `
    <a class="product-link" href="/pages/product.html?id=${product.id}">
      <div class="product-image">${imageContent}</div>
      <div class="product-info">
        <span class="product-condition ${product.condition}">${escapeHtml(conditionLabel)}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p class="product-description">${escapeHtml(product.description || "")}</p>
      </div>
    </a>
    <div class="product-bottom">
      <strong>${Number(product.price).toLocaleString("fa-IR")} تومان</strong>
      <button class="add-cart" type="button">افزودن</button>
    </div>
  `;

  card.querySelector(".add-cart").addEventListener("click", addToCart);

  return card;
}

// اول سعی می‌کنه بر اساس تاریخچه‌ی جستجوی همین کاربر/بازدیدکننده پیشنهاد بده؛
// اگه تاریخچه‌ای نبود (یا خالی بود)، به لیست عمومی محصولات برمی‌گرده
async function loadFeaturedProducts() {
  const container = document.getElementById("homeProducts");
  const emptyEl = document.getElementById("homeProductsEmpty");
  const titleEl = document.getElementById("homeProductsTitle");
  const subtitleEl = document.getElementById("homeProductsSubtitle");

  try {
    const recommendation = await apiRequest("/api/recommendations");

    if (recommendation.products.length > 0) {
      if (titleEl) titleEl.textContent = "پیشنهاد شده برای شما";
      if (subtitleEl) subtitleEl.textContent = "بر اساس جستجوهای اخیرت";

      recommendation.products.slice(0, 8).forEach((product) => {
        container.appendChild(renderProductCard(product));
      });
      return;
    }

    const { products } = await apiRequest("/api/products");

    if (products.length === 0) {
      emptyEl.textContent = "هنوز محصولی توی فروشگاه ثبت نشده.";
      return;
    }

    products.slice(0, 8).forEach((product) => {
      container.appendChild(renderProductCard(product));
    });
  } catch (err) {
    emptyEl.textContent = "خطا در دریافت محصولات: " + err.message;
  }
}

// جستجو دیگه اینجا نیست؛ باکس سرچ الان توسط js/search-box.js مدیریت می‌شه
// (پیشنهاد خودکار + رفتن به صفحه /pages/search.html با اینتر)

loadFeaturedProducts();
