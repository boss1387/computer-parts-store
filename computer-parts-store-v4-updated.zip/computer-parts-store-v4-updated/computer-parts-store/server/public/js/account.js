/* =========================
   وضعیت ورود کاربر عادی (مشتری) - مشترک بین صفحات
========================= */

let customerCsrfToken = null;
let currentCustomer = null;

async function checkCustomerAuth() {
  try {
    const res = await fetch("/api/account/me", { credentials: "include" });
    const data = await res.json();

    if (data.loggedIn) {
      customerCsrfToken = data.csrfToken;
      currentCustomer = data.user;
    } else {
      customerCsrfToken = null;
      currentCustomer = null;
    }

    return data.loggedIn ? currentCustomer : null;
  } catch {
    return null;
  }
}

async function logoutCustomer() {
  try {
    await fetch("/api/account/logout", { method: "POST", credentials: "include" });
  } catch {
    // اگه درخواست خطا داد، مهم نیست؛ کاربر رو به صفحه اصلی برمی‌گردونیم
  }
  window.location.href = "/pages/home.html";
}

function renderAccountButton(user) {
  const accountBtn = document.querySelector(".account-btn");
  if (!accountBtn) return;

  if (user) {
    accountBtn.textContent = `👤 ${user.firstName}`;
    accountBtn.removeAttribute("href");
    accountBtn.style.cursor = "pointer";
    accountBtn.title = "برای خروج از حساب کلیک کن";
    accountBtn.addEventListener("click", (event) => {
      event.preventDefault();
      if (confirm("از حسابت خارج بشی؟")) {
        logoutCustomer();
      }
    });
  } else {
    accountBtn.textContent = "👤 حساب کاربری";
    accountBtn.setAttribute("href", "/pages/register.html");
  }
}

checkCustomerAuth().then(renderAccountButton);
