/* =========================
   کمک‌کننده برای صدا زدن API
========================= */

let csrfToken = null;

// وضعیت لاگین ادمین رو از سرور می‌پرسه و csrf token رو (در صورت لاگین بودن) نگه می‌داره
async function checkAuth() {
  const res = await fetch("/api/me", { credentials: "include" });
  const data = await res.json();

  if (data.loggedIn) {
    csrfToken = data.csrfToken;
  } else {
    csrfToken = null;
  }

  return data.loggedIn;
}

// توکن CSRF برای درخواست‌هایی که خودشون fetch رو صدا می‌زنن (مثل آپلود فایل خام)
function getCsrfToken() {
  return csrfToken;
}

async function apiRequest(url, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };

  if (["POST", "PUT", "DELETE"].includes((options.method || "GET").toUpperCase()) && csrfToken) {
    headers["X-CSRF-Token"] = csrfToken;
  }

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: "include",
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || "خطایی رخ داد");
  }

  return data;
}

// جلوگیری از XSS وقتی متن دلخواه (مثل نام محصول) رو داخل HTML قرار می‌دیم
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = String(str ?? "");
  return div.innerHTML;
}
