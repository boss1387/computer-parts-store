/* =========================
   جستجو - پیشنهاد خودکار + رفتن به صفحه نتایج
========================= */

(function () {
  const input = document.getElementById("searchInput");
  if (!input) return;

  const box = input.closest(".search-box");
  const submitBtn = box ? box.querySelector("button") : null;

  // باکس پیشنهادها رو خودمون می‌سازیم تا لازم نباشه توی هر صفحه‌ای دستی اضافه بشه
  const dropdown = document.createElement("div");
  dropdown.className = "search-suggestions";
  dropdown.hidden = true;
  (box || input.parentElement).appendChild(dropdown);

  let activeIndex = -1;
  let currentItems = [];
  let debounceTimer = null;
  let requestToken = 0;

  function goToResults(query) {
    const trimmed = query.trim();
    if (!trimmed) return;
    window.location.href = `/pages/search.html?q=${encodeURIComponent(trimmed)}`;
  }

  function goToProduct(id) {
    window.location.href = `/pages/product.html?id=${id}`;
  }

  function closeDropdown() {
    dropdown.hidden = true;
    dropdown.innerHTML = "";
    currentItems = [];
    activeIndex = -1;
  }

  function categoryIcon(category) {
    const icons = { cpu: "🧠", gpu: "🎮", ram: "💾", storage: "💿", psu: "🔌", accessories: "⌨️" };
    return icons[category] || "📦";
  }

  function renderDropdown(items) {
    currentItems = items;
    activeIndex = -1;

    if (items.length === 0) {
      closeDropdown();
      return;
    }

    dropdown.innerHTML = items
      .map((item, index) => {
        if (item.type === "history") {
          return `
            <div class="search-suggestion-item" data-index="${index}">
              <span class="suggestion-icon">🕘</span>
              <span class="suggestion-text">${escapeHtml(item.text)}</span>
            </div>
          `;
        }

        const imageContent = item.primaryImage
          ? `<img src="${escapeHtml(item.primaryImage)}" alt="">`
          : `<span class="suggestion-icon">${categoryIcon(item.category)}</span>`;

        return `
          <div class="search-suggestion-item" data-index="${index}">
            <span class="suggestion-thumb">${imageContent}</span>
            <span class="suggestion-text">${escapeHtml(item.name)}</span>
          </div>
        `;
      })
      .join("");

    dropdown.hidden = false;

    dropdown.querySelectorAll(".search-suggestion-item").forEach((el) => {
      el.addEventListener("mousedown", (event) => {
        // mousedown نه click، چون blur ورودی زودتر از click اجرا می‌شه و باعث بسته شدن دراپ‌داون میشه
        event.preventDefault();
        selectItem(Number(el.dataset.index));
      });
    });
  }

  function selectItem(index) {
    const item = currentItems[index];
    if (!item) return;

    if (item.type === "history") {
      input.value = item.text;
      goToResults(item.text);
    } else {
      goToProduct(item.id);
    }

    closeDropdown();
  }

  function updateActiveHighlight() {
    dropdown.querySelectorAll(".search-suggestion-item").forEach((el, index) => {
      el.classList.toggle("active", index === activeIndex);
    });
  }

  async function fetchSuggestions(query) {
    const token = ++requestToken;

    try {
      const res = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`, {
        credentials: "include",
      });
      const data = await res.json();

      if (token !== requestToken) return; // یه درخواست جدیدتر در راهه، این جواب قدیمیه

      renderDropdown(data.suggestions || []);
    } catch {
      if (token === requestToken) closeDropdown();
    }
  }

  input.addEventListener("input", function () {
    clearTimeout(debounceTimer);
    const query = this.value;

    debounceTimer = setTimeout(() => {
      fetchSuggestions(query);
    }, 200);
  });

  input.addEventListener("focus", function () {
    if (this.value.trim() || true) {
      // با فوکوس (حتی خالی) تاریخچه‌ی قبلی رو نشون بده
      fetchSuggestions(this.value);
    }
  });

  input.addEventListener("keydown", function (event) {
    if (dropdown.hidden && event.key !== "Enter") return;

    if (event.key === "ArrowDown") {
      event.preventDefault();
      activeIndex = Math.min(activeIndex + 1, currentItems.length - 1);
      updateActiveHighlight();
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      activeIndex = Math.max(activeIndex - 1, -1);
      updateActiveHighlight();
    } else if (event.key === "Enter") {
      event.preventDefault();
      if (activeIndex >= 0 && currentItems[activeIndex]) {
        selectItem(activeIndex);
      } else {
        goToResults(this.value);
        closeDropdown();
      }
    } else if (event.key === "Escape") {
      closeDropdown();
    }
  });

  input.addEventListener("blur", function () {
    // با تاخیر کوچیک، تا mousedown روی آیتم زودتر ثبت بشه
    setTimeout(closeDropdown, 150);
  });

  if (submitBtn) {
    submitBtn.addEventListener("click", function (event) {
      event.preventDefault();
      goToResults(input.value);
    });
  }
})();
