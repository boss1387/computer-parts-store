/* =========================
   صفحه نتایج جستجو
========================= */

const searchQuery = new URLSearchParams(window.location.search).get("q") || "";

const searchTitleEl = document.getElementById("searchTitle");
const searchSubtitleEl = document.getElementById("searchSubtitle");
const searchResultsEl = document.getElementById("searchResults");
const searchEmptyEl = document.getElementById("searchEmpty");

const categoryIcons = {
  cpu: "🧠",
  gpu: "🎮",
  ram: "💾",
  storage: "💿",
  psu: "🔌",
  accessories: "⌨️",
};

let cartCount = 0;

function addToCart() {
  cartCount++;
  const cartCountElement = document.getElementById("cartCount");
  if (cartCountElement) cartCountElement.textContent = cartCount;
}

function renderProductCard(product) {
  const conditionLabel = product.condition === "new" ? "نو" : "دست دوم";
  const icon = categoryIcons[product.category] || "📦";

  const card = document.createElement("article");
  card.className = "product-card";

  const imageContent = product.primaryImage
    ? `<img src="${escapeHtml(product.primaryImage)}" alt="${escapeHtml(product.name)}" loading="lazy">`
    : icon;

  card.innerHTML = `
    <a class="product-link" href="/pages/product.html?id=${product.id}">
      <div class="product-image">${imageContent}</div>
      <div class="product-info">
        <span class="product-condition ${product.condition}">${escapeHtml(conditionLabel)}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p class="product-description">${escapeHtml(product.description || "")}</p>
      </div>
    </a>
    <div class="product-bottom">
      <strong>${Number(product.price).toLocaleString("fa-IR")} تومان</strong>
      <button class="add-cart" type="button">افزودن</button>
    </div>
  `;

  card.querySelector(".add-cart").addEventListener("click", addToCart);

  return card;
}

async function runSearch() {
  const input = document.getElementById("searchInput");
  if (input) input.value = searchQuery;

  if (!searchQuery.trim()) {
    searchTitleEl.textContent = "جستجو";
    searchSubtitleEl.textContent = "چیزی برای جستجو تایپ کن.";
    searchEmptyEl.style.display = "none";
    return;
  }

  searchTitleEl.textContent = `نتایج جستجو برای «${searchQuery}»`;
  searchSubtitleEl.textContent = "در حال جستجو...";
  searchEmptyEl.style.display = "none";

  try {
    const data = await apiRequest(`/api/search?q=${encodeURIComponent(searchQuery)}`);
    const products = data.products || [];

    searchSubtitleEl.textContent = products.length
      ? `${products.length} نتیجه پیدا شد`
      : "";

    if (products.length === 0) {
      searchEmptyEl.style.display = "block";
      searchEmptyEl.textContent = `چیزی برای «${searchQuery}» پیدا نشد.`;
      return;
    }

    products.forEach((product) => {
      searchResultsEl.appendChild(renderProductCard(product));
    });
  } catch (err) {
    searchSubtitleEl.textContent = "";
    searchEmptyEl.style.display = "block";
    searchEmptyEl.textContent = "خطا در دریافت نتایج: " + err.message;
  }
}

runSearch();
