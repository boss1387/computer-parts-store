/* =========================
   ورود ادمین - متصل به API واقعی
========================= */

const loginForm = document.getElementById("loginForm");
const loginError = document.getElementById("loginError");

if (loginForm) {
  loginForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (loginError) loginError.textContent = "";

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || "ورود ناموفق بود");
      }

      window.location.href = "admin.html";
    } catch (err) {
      if (loginError) {
        loginError.textContent = err.message;
      } else {
        alert(err.message);
      }
    }
  });
}
