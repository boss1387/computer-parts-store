/* =========================
   صفحه دسته‌بندی - متصل به API واقعی
========================= */

const urlParams = new URLSearchParams(window.location.search);
const categorySlug = urlParams.get("cat");

const categoryIconEl = document.getElementById("categoryIcon");
const categoryNameEl = document.getElementById("categoryName");
const categorySubtitleEl = document.getElementById("categorySubtitle");
const categoryProductsEl = document.getElementById("categoryProducts");
const categoryEmptyEl = document.getElementById("categoryEmpty");

function renderProductCard(product) {
  const conditionLabel = product.condition === "new" ? "نو" : "دست دوم";
  const icon = (window.__categoryInfo && window.__categoryInfo.icon) || "📦";

  const card = document.createElement("article");
  card.className = "product-card";

  const imageContent = product.primaryImage
    ? `<img src="${escapeHtml(product.primaryImage)}" alt="${escapeHtml(product.name)}" loading="lazy">`
    : icon;

  card.innerHTML = `
    <a class="product-link" href="/pages/product.html?id=${product.id}">
      <div class="product-image">${imageContent}</div>
      <div class="product-info">
        <span class="product-condition ${product.condition}">${escapeHtml(conditionLabel)}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p class="product-description">${escapeHtml(product.description || "")}</p>
      </div>
    </a>
    <div class="product-bottom">
      <strong>${Number(product.price).toLocaleString("fa-IR")} تومان</strong>
      <button class="add-cart" type="button">افزودن</button>
    </div>
  `;

  card.querySelector(".add-cart").addEventListener("click", addToCart);

  return card;
}

async function renderCategory() {
  try {
    const { categories } = await apiRequest("/api/categories");
    const categoryData = categories[categorySlug];

    if (!categoryData) {
      categoryIconEl.textContent = "❓";
      categoryNameEl.textContent = "دسته‌بندی پیدا نشد";
      categorySubtitleEl.textContent = "";
      categoryEmptyEl.style.display = "block";
      categoryEmptyEl.textContent = "همچین دسته‌بندی‌ای وجود نداره.";
      return;
    }

    window.__categoryInfo = categoryData;

    categoryIconEl.textContent = categoryData.icon;
    categoryNameEl.textContent = categoryData.name;
    categorySubtitleEl.textContent = categoryData.subtitle;

    const { products } = await apiRequest(`/api/products?category=${encodeURIComponent(categorySlug)}`);

    if (products.length === 0) {
      categoryEmptyEl.style.display = "block";
      categoryEmptyEl.textContent = "فعلاً محصولی در این دسته‌بندی ثبت نشده.";
      return;
    }

    products.forEach((product) => {
      categoryProductsEl.appendChild(renderProductCard(product));
    });
  } catch (err) {
    categoryEmptyEl.style.display = "block";
    categoryEmptyEl.textContent = "خطا در دریافت اطلاعات: " + err.message;
  }
}

/* =========================
   سبد خرید (مشترک با صفحه اصلی)
========================= */

let cartCount = 0;

function addToCart() {
  cartCount++;
  const cartCountElement = document.getElementById("cartCount");
  if (cartCountElement) cartCountElement.textContent = cartCount;
}

renderCategory();
