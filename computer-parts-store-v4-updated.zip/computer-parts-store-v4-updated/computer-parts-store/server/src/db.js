import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "..", "data");

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "store.db");
const db = new DatabaseSync(dbPath);

// امنیت و پایداری بیشتر
db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price INTEGER NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    description TEXT NOT NULL DEFAULT '',
    condition TEXT NOT NULL DEFAULT 'new',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    admin_id INTEGER NOT NULL,
    csrf_token TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
  );
`);

/* =========================================================
   کاربران عادی (مشتری‌ها) — جدا از جدول admins
========================================================= */
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL DEFAULT '',
    last_name TEXT NOT NULL DEFAULT '',
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS user_sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    csrf_token TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

/* =========================================================
   تاریخچه‌ی جستجو
   اگه کاربر لاگین باشه با user_id ذخیره می‌شه، وگرنه با
   visitor_id (یه شناسه‌ی ناشناس که توی کوکی مرورگر نگه داشته می‌شه)
   تا سرچ‌های قبلی‌ش بازم بهش پیشنهاد بشه.
========================================================= */
db.exec(`
  CREATE TABLE IF NOT EXISTS search_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    visitor_id TEXT,
    query TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_search_history_user
  ON search_history (user_id, created_at DESC);
`);

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_search_history_visitor
  ON search_history (visitor_id, created_at DESC);
`);

/* =========================================================
   عکس‌های محصول
   هر محصول می‌تونه هر تعداد عکس داشته باشه.
   position ترتیب نمایش رو مشخص می‌کنه (۰ یعنی عکس اصلی).
========================================================= */
db.exec(`
  CREATE TABLE IF NOT EXISTS product_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    url TEXT NOT NULL,
    alt TEXT NOT NULL DEFAULT '',
    position INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
  );
`);

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_product_images_product
  ON product_images (product_id, position);
`);

/* =========================================================
   ویژگی‌های محصول (مشخصات فنی)
   هر ردیف یک ویژگی‌ست که داخل یک گروه (مثلاً «مشخصات کلی») قرار می‌گیره.
   group_position ترتیب گروه‌ها، position ترتیب ویژگی‌ها داخل گروه.
========================================================= */
db.exec(`
  CREATE TABLE IF NOT EXISTS product_specs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    group_title TEXT NOT NULL DEFAULT '',
    group_position INTEGER NOT NULL DEFAULT 0,
    label TEXT NOT NULL,
    value TEXT NOT NULL DEFAULT '',
    position INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
  );
`);

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_product_specs_product
  ON product_specs (product_id, group_position, position);
`);

/* =========================================================
   مهاجرت (Migration)
   اگه دیتابیس از قبل ساخته شده بود، ستون‌های جدید رو اضافه می‌کنیم.
========================================================= */
function addColumnIfMissing(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all();
  const exists = columns.some((col) => col.name === column);

  if (!exists) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition};`);
  }
}

// توضیحات کامل و بلند محصول (جدا از description که خلاصه‌ی کوتاهه)
addColumnIfMissing("products", "long_description", "TEXT NOT NULL DEFAULT ''");

// برند و مدل — توی صفحه محصول کاربرد دارن
addColumnIfMissing("products", "brand", "TEXT NOT NULL DEFAULT ''");
addColumnIfMissing("products", "model", "TEXT NOT NULL DEFAULT ''");

// گارانتی
addColumnIfMissing("products", "warranty", "TEXT NOT NULL DEFAULT ''");

export default db;
