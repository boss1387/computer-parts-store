// محدودکننده ساده برای جلوگیری از حمله brute-force روی صفحه ورود
// (برای production با ترافیک بالا، بهتره از Redis استفاده بشه)

const attempts = new Map(); // key: ip -> { count, resetAt }

const WINDOW_MS = 15 * 60 * 1000; // ۱۵ دقیقه
const MAX_ATTEMPTS = 8;

export function isRateLimited(ip) {
  const now = Date.now();
  const entry = attempts.get(ip);

  if (!entry || entry.resetAt < now) {
    return false;
  }

  return entry.count >= MAX_ATTEMPTS;
}

export function recordFailedAttempt(ip) {
  const now = Date.now();
  const entry = attempts.get(ip);

  if (!entry || entry.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return;
  }

  entry.count++;
}

export function clearAttempts(ip) {
  attempts.delete(ip);
}
