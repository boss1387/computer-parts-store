import crypto from "node:crypto";

const KEY_LENGTH = 64;
const SCRYPT_OPTS = { N: 16384, r: 8, p: 1 };

// رمز عبور رو هش می‌کنه (salt رندوم + scrypt) و به صورت "salt:hash" برمی‌گردونه
export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, KEY_LENGTH, SCRYPT_OPTS);
  return `${salt.toString("hex")}:${hash.toString("hex")}`;
}

// رمز واردشده رو با هش ذخیره‌شده مقایسه می‌کنه (بدون افشای زمان‌بندی - timing safe)
export function verifyPassword(password, stored) {
  const [saltHex, hashHex] = String(stored).split(":");
  if (!saltHex || !hashHex) return false;

  const salt = Buffer.from(saltHex, "hex");
  const storedHash = Buffer.from(hashHex, "hex");
  const attemptHash = crypto.scryptSync(password, salt, storedHash.length, SCRYPT_OPTS);

  return (
    storedHash.length === attemptHash.length &&
    crypto.timingSafeEqual(storedHash, attemptHash)
  );
}

export function isStrongPassword(password) {
  return typeof password === "string" && password.length >= 8;
}
