import crypto from "node:crypto";
import db from "./db.js";

const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // ۷ روز

const insertSession = db.prepare(
  "INSERT INTO sessions (id, admin_id, csrf_token, expires_at) VALUES (?, ?, ?, ?)"
);
const selectSession = db.prepare("SELECT * FROM sessions WHERE id = ?");
const deleteSessionStmt = db.prepare("DELETE FROM sessions WHERE id = ?");
const deleteExpiredStmt = db.prepare("DELETE FROM sessions WHERE expires_at < ?");

export function createSession(adminId) {
  const id = crypto.randomBytes(32).toString("hex");
  const csrfToken = crypto.randomBytes(32).toString("hex");
  const expiresAt = Date.now() + SESSION_TTL_MS;

  insertSession.run(id, adminId, csrfToken, expiresAt);

  return { id, csrfToken, expiresAt };
}

export function getSession(sessionId) {
  if (!sessionId) return null;

  deleteExpiredStmt.run(Date.now());

  const session = selectSession.get(sessionId);
  if (!session) return null;

  if (session.expires_at < Date.now()) {
    deleteSessionStmt.run(sessionId);
    return null;
  }

  return session;
}

export function destroySession(sessionId) {
  if (!sessionId) return;
  deleteSessionStmt.run(sessionId);
}
