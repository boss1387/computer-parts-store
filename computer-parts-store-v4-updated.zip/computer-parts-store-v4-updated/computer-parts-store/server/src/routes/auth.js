import db from "../db.js";
import { verifyPassword } from "../auth.js";
import { createSession, destroySession } from "../sessions.js";
import { parseCookies, setCookie, sendJson, readJsonBody } from "../http-helpers.js";
import { isRateLimited, recordFailedAttempt, clearAttempts } from "../ratelimit.js";

const findAdminByEmail = db.prepare("SELECT * FROM admins WHERE email = ?");

const isProd = process.env.NODE_ENV === "production";

export async function handleLogin(req, res) {
  const ip = req.socket.remoteAddress || "unknown";

  if (isRateLimited(ip)) {
    sendJson(res, 429, {
      ok: false,
      error: "تعداد تلاش‌های ناموفق بیش از حد مجازه. چند دقیقه دیگه دوباره امتحان کن.",
    });
    return;
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  if (!email || !password) {
    sendJson(res, 400, { ok: false, error: "ایمیل و رمز عبور الزامیه" });
    return;
  }

  const admin = findAdminByEmail.get(email);

  // برای جلوگیری از "user enumeration"، پیام خطا برای ایمیل غلط و رمز غلط یکسانه
  if (!admin || !verifyPassword(password, admin.password_hash)) {
    recordFailedAttempt(ip);
    sendJson(res, 401, { ok: false, error: "ایمیل یا رمز عبور اشتباه است." });
    return;
  }

  clearAttempts(ip);

  const session = createSession(admin.id);

  setCookie(res, "session_id", session.id, {
    maxAge: 1000 * 60 * 60 * 24 * 7,
    secure: isProd,
    sameSite: "Strict",
  });

  sendJson(res, 200, { ok: true, csrfToken: session.csrfToken });
}

export async function handleLogout(req, res) {
  const cookies = parseCookies(req);
  destroySession(cookies.session_id);

  setCookie(res, "session_id", "", { expires: 0, secure: isProd });
  sendJson(res, 200, { ok: true });
}

export async function handleMe(req, res, session) {
  if (!session) {
    sendJson(res, 200, { loggedIn: false });
    return;
  }

  sendJson(res, 200, { loggedIn: true, csrfToken: session.csrf_token });
}
