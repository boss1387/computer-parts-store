import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

import { sendJson } from "../http-helpers.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// عکس‌ها داخل public ذخیره می‌شن تا سرور استاتیک خودش سروشون کنه
export const UPLOADS_DIR = path.join(__dirname, "..", "..", "public", "uploads");

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // ۵ مگابایت برای هر عکس

// فقط این فرمت‌ها قبول می‌شن. پسوند فایل رو خودمون از روی همین جدول می‌سازیم،
// نه از روی چیزی که کلاینت فرستاده — پس نمی‌شه فایل .html یا .js آپلود کرد.
const ALLOWED_TYPES = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "image/avif": ".avif",
};

// امضای بایتی (magic bytes) هر فرمت — چک می‌کنیم فایل واقعاً همونیه که ادعا می‌کنه
function detectImageType(buffer) {
  if (buffer.length < 12) return null;

  // JPEG: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return "image/jpeg";
  }

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  ) {
    return "image/png";
  }

  // GIF: "GIF8"
  if (buffer.toString("ascii", 0, 4) === "GIF8") {
    return "image/gif";
  }

  // WebP: "RIFF" .... "WEBP"
  if (
    buffer.toString("ascii", 0, 4) === "RIFF" &&
    buffer.toString("ascii", 8, 12) === "WEBP"
  ) {
    return "image/webp";
  }

  // AVIF: "....ftypavif"
  if (buffer.toString("ascii", 4, 8) === "ftyp") {
    const brand = buffer.toString("ascii", 8, 12);
    if (brand === "avif" || brand === "avis") return "image/avif";
  }

  return null;
}

function readRawBody(req, maxSize) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];

    req.on("data", (chunk) => {
      size += chunk.length;

      if (size > maxSize) {
        reject({ statusCode: 413, message: "حجم عکس بیشتر از ۵ مگابایته" });
        req.destroy();
        return;
      }

      chunks.push(chunk);
    });

    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", () => reject({ statusCode: 400, message: "خطا در دریافت فایل" }));
  });
}

/* =========================================================
   POST /api/uploads
   بدنه‌ی درخواست = خود بایت‌های عکس (بدون multipart)
   هر درخواست یک عکس. برای چند عکس، چند درخواست پشت‌سرهم فرستاده می‌شه.
========================================================= */
export async function handleUploadImage(req, res) {
  let buffer;

  try {
    buffer = await readRawBody(req, MAX_IMAGE_SIZE);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  if (buffer.length === 0) {
    sendJson(res, 400, { ok: false, error: "فایلی دریافت نشد" });
    return;
  }

  const detectedType = detectImageType(buffer);

  if (!detectedType || !ALLOWED_TYPES[detectedType]) {
    sendJson(res, 400, {
      ok: false,
      error: "فقط عکس با فرمت JPG، PNG، WebP، GIF یا AVIF قابل آپلوده",
    });
    return;
  }

  const extension = ALLOWED_TYPES[detectedType];
  const fileName = `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${extension}`;
  const filePath = path.join(UPLOADS_DIR, fileName);

  try {
    await fs.promises.writeFile(filePath, buffer);
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { ok: false, error: "ذخیره‌ی عکس روی سرور انجام نشد" });
    return;
  }

  sendJson(res, 201, {
    ok: true,
    url: `/uploads/${fileName}`,
    size: buffer.length,
    type: detectedType,
  });
}

/* =========================================================
   پاک کردن فایل عکس از دیسک
   وقتی عکسی از محصول حذف می‌شه و جای دیگه‌ای استفاده نشده، فایلش هم پاک می‌شه.
========================================================= */
export function deleteUploadedFile(url) {
  if (typeof url !== "string" || !url.startsWith("/uploads/")) return;

  const fileName = path.basename(url);
  const filePath = path.join(UPLOADS_DIR, fileName);

  // مطمئن می‌شیم مسیر از پوشه‌ی آپلود بیرون نزده
  if (!filePath.startsWith(UPLOADS_DIR)) return;

  fs.promises.unlink(filePath).catch(() => {
    // اگه فایل از قبل نبود، مشکلی نیست
  });
}
