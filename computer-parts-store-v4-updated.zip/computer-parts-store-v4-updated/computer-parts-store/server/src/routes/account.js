import db from "../db.js";
import { hashPassword, verifyPassword, isStrongPassword } from "../auth.js";
import { createUserSession, destroyUserSession } from "../user-sessions.js";
import { parseCookies, setCookie, sendJson, readJsonBody } from "../http-helpers.js";
import { isRateLimited, recordFailedAttempt, clearAttempts } from "../ratelimit.js";

const isProd = process.env.NODE_ENV === "production";

const findUserByEmail = db.prepare("SELECT * FROM users WHERE email = ?");
const findUserById = db.prepare("SELECT id, first_name, last_name, email FROM users WHERE id = ?");
const insertUser = db.prepare(`
  INSERT INTO users (first_name, last_name, email, password_hash)
  VALUES (?, ?, ?, ?)
`);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function publicUser(row) {
  if (!row) return null;
  return { id: row.id, firstName: row.first_name, lastName: row.last_name, email: row.email };
}

function setCustomerCookie(res, sessionId) {
  setCookie(res, "customer_session", sessionId, {
    maxAge: 1000 * 60 * 60 * 24 * 30,
    secure: isProd,
    sameSite: "Strict",
  });
}

export async function handleRegister(req, res) {
  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  const firstName = String(body.firstName || "").trim();
  const lastName = String(body.lastName || "").trim();
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const confirmPassword = String(body.confirmPassword || "");

  const errors = [];

  if (!firstName || firstName.length > 100) errors.push("نام نامعتبره");
  if (!lastName || lastName.length > 100) errors.push("نام خانوادگی نامعتبره");
  if (!EMAIL_RE.test(email) || email.length > 200) errors.push("ایمیل نامعتبره");
  if (!isStrongPassword(password)) errors.push("رمز عبور باید حداقل ۸ کاراکتر باشه");
  if (password !== confirmPassword) errors.push("رمز عبور و تکرارش یکسان نیستن");

  if (errors.length > 0) {
    sendJson(res, 400, { ok: false, error: errors.join(" / ") });
    return;
  }

  if (findUserByEmail.get(email)) {
    sendJson(res, 409, { ok: false, error: "قبلاً با این ایمیل حساب ساخته شده" });
    return;
  }

  const passwordHash = hashPassword(password);
  const info = insertUser.run(firstName, lastName, email, passwordHash);
  const userId = Number(info.lastInsertRowid);

  const session = createUserSession(userId);
  setCustomerCookie(res, session.id);

  sendJson(res, 201, {
    ok: true,
    csrfToken: session.csrfToken,
    user: publicUser(findUserById.get(userId)),
  });
}

export async function handleAccountLogin(req, res) {
  const ip = req.socket.remoteAddress || "unknown";
  const rateLimitKey = `account:${ip}`;

  if (isRateLimited(rateLimitKey)) {
    sendJson(res, 429, {
      ok: false,
      error: "تعداد تلاش‌های ناموفق بیش از حد مجازه. چند دقیقه دیگه دوباره امتحان کن.",
    });
    return;
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  if (!email || !password) {
    sendJson(res, 400, { ok: false, error: "ایمیل و رمز عبور الزامیه" });
    return;
  }

  const user = findUserByEmail.get(email);

  if (!user || !verifyPassword(password, user.password_hash)) {
    recordFailedAttempt(rateLimitKey);
    sendJson(res, 401, { ok: false, error: "ایمیل یا رمز عبور اشتباه است." });
    return;
  }

  clearAttempts(rateLimitKey);

  const session = createUserSession(user.id);
  setCustomerCookie(res, session.id);

  sendJson(res, 200, {
    ok: true,
    csrfToken: session.csrfToken,
    user: publicUser(user),
  });
}

export async function handleAccountLogout(req, res) {
  const cookies = parseCookies(req);
  destroyUserSession(cookies.customer_session);

  setCookie(res, "customer_session", "", { expires: 0, secure: isProd });
  sendJson(res, 200, { ok: true });
}

export async function handleAccountMe(req, res, session) {
  if (!session) {
    sendJson(res, 200, { loggedIn: false });
    return;
  }

  const user = findUserById.get(session.user_id);

  if (!user) {
    sendJson(res, 200, { loggedIn: false });
    return;
  }

  sendJson(res, 200, { loggedIn: true, csrfToken: session.csrf_token, user: publicUser(user) });
}
