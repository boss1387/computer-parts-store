import db from "../db.js";
import { sendJson } from "../http-helpers.js";
import categories from "../../config/categories.json" with { type: "json" };

const MAX_SUGGESTIONS = 8;
const MAX_HISTORY_ITEMS_SHOWN = 5;
const MAX_HISTORY_ROWS_PER_OWNER = 50; // برای جلوگیری از رشد بی‌رویه‌ی جدول
const MAX_QUERY_LENGTH = 200;
const MAX_RECOMMENDATION_QUERIES = 5; // چند سرچ اخیر رو برای پیشنهاد در نظر بگیریم
const MAX_RECOMMENDATIONS = 8;

/* =========================
   کوئری‌های محصولات (برای جستجو)
========================= */

const selectAllForSearch = db.prepare(
  "SELECT id, name, category, brand, model, description, price, condition FROM products"
);

const selectPrimaryImages = db.prepare(`
  SELECT product_id, url
  FROM product_images
  WHERE position = (
    SELECT MIN(position) FROM product_images AS inner_img WHERE inner_img.product_id = product_images.product_id
  )
  GROUP BY product_id
`);

/* =========================
   کوئری‌های تاریخچه‌ی جستجو
========================= */

const insertHistoryByUser = db.prepare(
  "INSERT INTO search_history (user_id, query) VALUES (?, ?)"
);
const insertHistoryByVisitor = db.prepare(
  "INSERT INTO search_history (visitor_id, query) VALUES (?, ?)"
);

const selectRecentHistoryByUser = db.prepare(`
  SELECT query, MAX(created_at) AS last_at
  FROM search_history
  WHERE user_id = ?
  GROUP BY query
  ORDER BY last_at DESC
  LIMIT ?
`);
const selectRecentHistoryByVisitor = db.prepare(`
  SELECT query, MAX(created_at) AS last_at
  FROM search_history
  WHERE visitor_id = ?
  GROUP BY query
  ORDER BY last_at DESC
  LIMIT ?
`);

const trimHistoryByUser = db.prepare(`
  DELETE FROM search_history
  WHERE user_id = ?
    AND id NOT IN (
      SELECT id FROM search_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?
    )
`);
const trimHistoryByVisitor = db.prepare(`
  DELETE FROM search_history
  WHERE visitor_id = ?
    AND id NOT IN (
      SELECT id FROM search_history WHERE visitor_id = ? ORDER BY created_at DESC LIMIT ?
    )
`);

/* =========================
   نرمال‌سازی و امتیازدهی متن فارسی/انگلیسی
========================= */

function normalizeText(str) {
  return String(str || "")
    .toLowerCase()
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[\u200c\u200f\u200e]/g, " ") // نیم‌فاصله و کاراکترهای جهت‌دهی نامرئی
    .replace(/\s+/g, " ")
    .trim();
}

function tokenize(normalizedQuery) {
  return normalizedQuery.split(" ").filter(Boolean);
}

// اگه هیچ‌کدوم از کلمه‌های سرچ توی محصول پیدا نشه، یعنی بی‌ربطه و نباید نشون داده بشه
function scoreProduct(product, categoryName, query, tokens) {
  const name = normalizeText(product.name);
  const brand = normalizeText(product.brand);
  const model = normalizeText(product.model);
  const description = normalizeText(product.description);
  const searchable = [name, brand, model, description, categoryName].join(" ");

  const allTokensMatch = tokens.every((token) => searchable.includes(token));
  if (!allTokensMatch) return -1;

  let score = 0;

  if (name === query) score += 100;
  else if (name.startsWith(query)) score += 60;
  else if (name.includes(query)) score += 40;

  tokens.forEach((token) => {
    if (name.includes(token)) score += 10;
    if (brand.includes(token)) score += 5;
    if (model.includes(token)) score += 5;
    if (categoryName.includes(token)) score += 3;
    if (description.includes(token)) score += 1;
  });

  return score;
}

function findMatchingProducts(rawQuery) {
  const query = normalizeText(rawQuery);
  if (!query) return [];

  const tokens = tokenize(query);
  const rows = selectAllForSearch.all();

  const primaryByProduct = new Map(
    selectPrimaryImages.all().map((row) => [row.product_id, row.url])
  );

  return rows
    .map((product) => {
      const categoryName = normalizeText(categories[product.category]?.name || "");
      return { product, score: scoreProduct(product, categoryName, query, tokens) };
    })
    .filter((entry) => entry.score >= 0)
    .sort((a, b) => b.score - a.score || String(a.product.name).localeCompare(String(b.product.name), "fa"))
    .map((entry) => ({
      ...entry.product,
      primaryImage: primaryByProduct.get(entry.product.id) || null,
    }));
}

/* =========================
   تاریخچه‌ی جستجوی این کاربر/بازدیدکننده
========================= */

function getRecentHistory(owner) {
  if (owner.userId) {
    return selectRecentHistoryByUser.all(owner.userId, 20).map((row) => row.query);
  }
  if (owner.visitorId) {
    return selectRecentHistoryByVisitor.all(owner.visitorId, 20).map((row) => row.query);
  }
  return [];
}

function saveHistory(owner, rawQuery) {
  const query = rawQuery.trim().slice(0, MAX_QUERY_LENGTH);
  if (!query) return;

  if (owner.userId) {
    insertHistoryByUser.run(owner.userId, query);
    trimHistoryByUser.run(owner.userId, owner.userId, MAX_HISTORY_ROWS_PER_OWNER);
  } else if (owner.visitorId) {
    insertHistoryByVisitor.run(owner.visitorId, query);
    trimHistoryByVisitor.run(owner.visitorId, owner.visitorId, MAX_HISTORY_ROWS_PER_OWNER);
  }
}

/* =========================
   هندلرها
========================= */

// GET /api/search/suggestions?q=...
// هرچی کاربر تایپ می‌کنه: هم از تاریخچه‌ی خودش، هم از اسم محصولات مشابه پیشنهاد می‌ده
export function handleGetSuggestions(req, res, query, owner) {
  const rawQuery = (query.get("q") || "").trim();
  const normalizedQuery = normalizeText(rawQuery);

  const history = getRecentHistory(owner)
    .filter((q) => !normalizedQuery || normalizeText(q).includes(normalizedQuery))
    .slice(0, MAX_HISTORY_ITEMS_SHOWN)
    .map((q) => ({ type: "history", text: q }));

  let productSuggestions = [];
  if (normalizedQuery) {
    productSuggestions = findMatchingProducts(rawQuery)
      .slice(0, Math.max(0, MAX_SUGGESTIONS - history.length))
      .map((p) => ({
        type: "product",
        id: p.id,
        name: p.name,
        category: p.category,
        price: p.price,
        primaryImage: p.primaryImage,
      }));
  }

  sendJson(res, 200, { ok: true, suggestions: [...history, ...productSuggestions] });
}

// GET /api/search?q=...
// نتایج کامل جستجو؛ اگه چیزی مطابقت نداشته باشه، لیست خالی برمی‌گرده (فرانت پیام "پیدا نشد" رو نشون می‌ده)
export function handleSearch(req, res, query, owner) {
  const rawQuery = (query.get("q") || "").trim();

  if (!rawQuery) {
    sendJson(res, 200, { ok: true, query: "", products: [] });
    return;
  }

  if (rawQuery.length > MAX_QUERY_LENGTH) {
    sendJson(res, 400, { ok: false, error: "متن جستجو خیلی بلنده" });
    return;
  }

  const products = findMatchingProducts(rawQuery);

  saveHistory(owner, rawQuery);

  sendJson(res, 200, { ok: true, query: rawQuery, products });
}

/* =========================
   محصولات پیشنهادی بر اساس تاریخچه‌ی جستجوی همین کاربر/بازدیدکننده
   (سرچ‌های اخیرش رو می‌گیریم و برای هر کدوم محصولات مشابه رو پیدا می‌کنیم)
========================= */

// GET /api/recommendations
export function handleGetRecommendations(req, res, owner) {
  const recentQueries = getRecentHistory(owner).slice(0, MAX_RECOMMENDATION_QUERIES);

  if (recentQueries.length === 0) {
    sendJson(res, 200, { ok: true, basedOn: [], products: [] });
    return;
  }

  const seenProductIds = new Set();
  const recommended = [];

  // سرچ‌های جدیدتر اول بررسی می‌شن، پس محصولات مرتبط با آخرین سرچ اولویت بیشتری دارن
  for (const query of recentQueries) {
    const matches = findMatchingProducts(query);

    for (const product of matches) {
      if (seenProductIds.has(product.id)) continue;

      seenProductIds.add(product.id);
      recommended.push(product);

      if (recommended.length >= MAX_RECOMMENDATIONS) break;
    }

    if (recommended.length >= MAX_RECOMMENDATIONS) break;
  }

  sendJson(res, 200, { ok: true, basedOn: recentQueries, products: recommended });
}
