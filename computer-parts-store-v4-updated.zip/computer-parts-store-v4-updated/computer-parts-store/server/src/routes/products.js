import db from "../db.js";
import { sendJson, readJsonBody } from "../http-helpers.js";
import { deleteUploadedFile } from "./uploads.js";
import categories from "../../config/categories.json" with { type: "json" };

const CATEGORY_KEYS = Object.keys(categories);
const CONDITIONS = ["new", "used"];

const MAX_IMAGES = 40;      // سقف منطقی برای جلوگیری از سوءاستفاده
const MAX_SPEC_GROUPS = 20;
const MAX_SPECS_PER_GROUP = 40;

/* =========================
   کوئری‌های آماده
========================= */

const selectAll = db.prepare("SELECT * FROM products ORDER BY created_at DESC");
const selectByCategory = db.prepare(
  "SELECT * FROM products WHERE category = ? ORDER BY created_at DESC"
);
const selectById = db.prepare("SELECT * FROM products WHERE id = ?");

const insertProduct = db.prepare(`
  INSERT INTO products
    (name, category, price, stock, description, long_description, condition, brand, model, warranty)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

const updateProduct = db.prepare(`
  UPDATE products
  SET name = ?, category = ?, price = ?, stock = ?, description = ?,
      long_description = ?, condition = ?, brand = ?, model = ?, warranty = ?,
      updated_at = datetime('now')
  WHERE id = ?
`);

const deleteProduct = db.prepare("DELETE FROM products WHERE id = ?");

// عکس‌ها
const selectImages = db.prepare(
  "SELECT id, url, alt, position FROM product_images WHERE product_id = ? ORDER BY position ASC, id ASC"
);
const insertImage = db.prepare(
  "INSERT INTO product_images (product_id, url, alt, position) VALUES (?, ?, ?, ?)"
);
const deleteImagesOfProduct = db.prepare("DELETE FROM product_images WHERE product_id = ?");

// عکس اصلی همه‌ی محصولات با یک کوئری (برای لیست محصولات)
const selectPrimaryImages = db.prepare(`
  SELECT product_id, url
  FROM product_images
  WHERE position = (
    SELECT MIN(position) FROM product_images AS inner_img WHERE inner_img.product_id = product_images.product_id
  )
  GROUP BY product_id
`);

// ویژگی‌ها
const selectSpecs = db.prepare(`
  SELECT group_title, group_position, label, value, position
  FROM product_specs
  WHERE product_id = ?
  ORDER BY group_position ASC, position ASC, id ASC
`);
const insertSpec = db.prepare(`
  INSERT INTO product_specs (product_id, group_title, group_position, label, value, position)
  VALUES (?, ?, ?, ?, ?, ?)
`);
const deleteSpecsOfProduct = db.prepare("DELETE FROM product_specs WHERE product_id = ?");

/* =========================
   اعتبارسنجی ورودی
========================= */

function validateProductInput(body) {
  const errors = [];

  const name = String(body.name || "").trim();
  const category = String(body.category || "");
  const price = Number(body.price);
  const stock = Number(body.stock);
  const description = String(body.description || "").trim();
  const longDescription = String(body.longDescription ?? body.long_description ?? "").trim();
  const condition = String(body.condition || "new");
  const brand = String(body.brand || "").trim();
  const model = String(body.model || "").trim();
  const warranty = String(body.warranty || "").trim();

  if (!name || name.length > 200) errors.push("نام محصول نامعتبره");
  if (!CATEGORY_KEYS.includes(category)) errors.push("دسته‌بندی نامعتبره");
  if (!Number.isFinite(price) || price < 0) errors.push("قیمت نامعتبره");
  if (!Number.isFinite(stock) || stock < 0) errors.push("موجودی نامعتبره");
  if (!CONDITIONS.includes(condition)) errors.push("وضعیت کالا نامعتبره");
  if (description.length > 500) errors.push("توضیح کوتاه نباید بیشتر از ۵۰۰ کاراکتر باشه");
  if (longDescription.length > 20000) errors.push("توضیحات کامل خیلی بلنده");
  if (brand.length > 100) errors.push("نام برند خیلی بلنده");
  if (model.length > 100) errors.push("نام مدل خیلی بلنده");
  if (warranty.length > 200) errors.push("متن گارانتی خیلی بلنده");

  /* ---- عکس‌ها ---- */
  const rawImages = Array.isArray(body.images) ? body.images : [];

  if (rawImages.length > MAX_IMAGES) {
    errors.push(`حداکثر ${MAX_IMAGES} عکس برای هر محصول مجازه`);
  }

  const images = [];
  rawImages.slice(0, MAX_IMAGES).forEach((item, index) => {
    // هم رشته‌ی ساده قبوله، هم آبجکت {url, alt}
    const url = typeof item === "string" ? item : String(item?.url || "");
    const alt = typeof item === "string" ? "" : String(item?.alt || "").trim();

    // فقط عکس‌هایی که خودمون آپلود کردیم — جلوگیری از تزریق لینک دلخواه
    if (!url.startsWith("/uploads/")) return;
    if (url.includes("..")) return;

    images.push({ url, alt: alt.slice(0, 200), position: index });
  });

  /* ---- گروه‌های ویژگی ---- */
  const rawGroups = Array.isArray(body.specGroups) ? body.specGroups : [];

  if (rawGroups.length > MAX_SPEC_GROUPS) {
    errors.push(`حداکثر ${MAX_SPEC_GROUPS} گروه ویژگی مجازه`);
  }

  const specs = [];
  rawGroups.slice(0, MAX_SPEC_GROUPS).forEach((group, groupIndex) => {
    const groupTitle = String(group?.title || "").trim().slice(0, 120);
    const items = Array.isArray(group?.items) ? group.items : [];

    items.slice(0, MAX_SPECS_PER_GROUP).forEach((item, itemIndex) => {
      const label = String(item?.label || "").trim().slice(0, 120);
      const value = String(item?.value || "").trim().slice(0, 500);

      // ویژگی بدون عنوان معنی نداره، ردش می‌کنیم
      if (!label) return;

      specs.push({
        groupTitle,
        groupPosition: groupIndex,
        label,
        value,
        position: itemIndex,
      });
    });
  });

  return {
    errors,
    value: {
      name,
      category,
      price,
      stock,
      description,
      longDescription,
      condition,
      brand,
      model,
      warranty,
      images,
      specs,
    },
  };
}

/* =========================
   کمک‌کننده‌ها
========================= */

// ردیف‌های تخت ویژگی‌ها رو به ساختار گروه‌بندی‌شده تبدیل می‌کنه
function groupSpecs(rows) {
  const groups = [];
  const indexByKey = new Map();

  rows.forEach((row) => {
    const key = `${row.group_position}|${row.group_title}`;

    if (!indexByKey.has(key)) {
      indexByKey.set(key, groups.length);
      groups.push({ title: row.group_title, items: [] });
    }

    groups[indexByKey.get(key)].items.push({ label: row.label, value: row.value });
  });

  return groups;
}

function loadFullProduct(id) {
  const product = selectById.get(id);
  if (!product) return null;

  const images = selectImages.all(id);
  const specGroups = groupSpecs(selectSpecs.all(id));

  return {
    ...product,
    images,
    specGroups,
    primaryImage: images.length > 0 ? images[0].url : null,
  };
}

// ذخیره‌ی عکس‌ها و ویژگی‌ها؛ عکس‌های حذف‌شده از دیسک هم پاک می‌شن
function saveImagesAndSpecs(productId, images, specs) {
  const previousImages = selectImages.all(productId);

  deleteImagesOfProduct.run(productId);
  deleteSpecsOfProduct.run(productId);

  images.forEach((image) => {
    insertImage.run(productId, image.url, image.alt, image.position);
  });

  specs.forEach((spec) => {
    insertSpec.run(
      productId,
      spec.groupTitle,
      spec.groupPosition,
      spec.label,
      spec.value,
      spec.position
    );
  });

  // فایل عکس‌هایی که دیگه استفاده نمی‌شن رو از روی دیسک پاک کن
  const keptUrls = new Set(images.map((img) => img.url));
  previousImages
    .filter((img) => !keptUrls.has(img.url))
    .forEach((img) => deleteUploadedFile(img.url));
}

/* =========================
   هندلرها
========================= */

export function handleGetProducts(req, res, query) {
  const category = query.get("category");

  const rows =
    category && CATEGORY_KEYS.includes(category)
      ? selectByCategory.all(category)
      : selectAll.all();

  // عکس اصلی هر محصول رو به لیست اضافه می‌کنیم تا کارت‌ها عکس داشته باشن
  const primaryByProduct = new Map(
    selectPrimaryImages.all().map((row) => [row.product_id, row.url])
  );

  const products = rows.map((row) => ({
    ...row,
    primaryImage: primaryByProduct.get(row.id) || null,
  }));

  sendJson(res, 200, { ok: true, products });
}

export function handleGetProduct(req, res, id) {
  const product = loadFullProduct(id);

  if (!product) {
    sendJson(res, 404, { ok: false, error: "محصول پیدا نشد" });
    return;
  }

  sendJson(res, 200, { ok: true, product });
}

export async function handleCreateProduct(req, res) {
  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  const { errors, value } = validateProductInput(body);
  if (errors.length > 0) {
    sendJson(res, 400, { ok: false, error: errors.join(" / ") });
    return;
  }

  const info = insertProduct.run(
    value.name,
    value.category,
    value.price,
    value.stock,
    value.description,
    value.longDescription,
    value.condition,
    value.brand,
    value.model,
    value.warranty
  );

  const productId = Number(info.lastInsertRowid);
  saveImagesAndSpecs(productId, value.images, value.specs);

  sendJson(res, 201, { ok: true, product: loadFullProduct(productId) });
}

export async function handleUpdateProduct(req, res, id) {
  const existing = selectById.get(id);
  if (!existing) {
    sendJson(res, 404, { ok: false, error: "محصول پیدا نشد" });
    return;
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
    return;
  }

  const { errors, value } = validateProductInput(body);
  if (errors.length > 0) {
    sendJson(res, 400, { ok: false, error: errors.join(" / ") });
    return;
  }

  updateProduct.run(
    value.name,
    value.category,
    value.price,
    value.stock,
    value.description,
    value.longDescription,
    value.condition,
    value.brand,
    value.model,
    value.warranty,
    id
  );

  saveImagesAndSpecs(id, value.images, value.specs);

  sendJson(res, 200, { ok: true, product: loadFullProduct(id) });
}

export function handleDeleteProduct(req, res, id) {
  const existing = selectById.get(id);
  if (!existing) {
    sendJson(res, 404, { ok: false, error: "محصول پیدا نشد" });
    return;
  }

  // اول فایل عکس‌ها رو پاک کن، بعد خود محصول رو
  selectImages.all(id).forEach((img) => deleteUploadedFile(img.url));

  deleteProduct.run(id);
  sendJson(res, 200, { ok: true });
}
