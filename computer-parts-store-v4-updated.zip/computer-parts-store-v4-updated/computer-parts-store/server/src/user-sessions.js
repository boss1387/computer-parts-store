import crypto from "node:crypto";
import db from "./db.js";

const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30; // ۳۰ روز — کاربر عادی نیازی نیست هر هفته دوباره وارد بشه

const insertSession = db.prepare(
  "INSERT INTO user_sessions (id, user_id, csrf_token, expires_at) VALUES (?, ?, ?, ?)"
);
const selectSession = db.prepare("SELECT * FROM user_sessions WHERE id = ?");
const deleteSessionStmt = db.prepare("DELETE FROM user_sessions WHERE id = ?");
const deleteExpiredStmt = db.prepare("DELETE FROM user_sessions WHERE expires_at < ?");

export function createUserSession(userId) {
  const id = crypto.randomBytes(32).toString("hex");
  const csrfToken = crypto.randomBytes(32).toString("hex");
  const expiresAt = Date.now() + SESSION_TTL_MS;

  insertSession.run(id, userId, csrfToken, expiresAt);

  return { id, csrfToken, expiresAt };
}

export function getUserSession(sessionId) {
  if (!sessionId) return null;

  deleteExpiredStmt.run(Date.now());

  const session = selectSession.get(sessionId);
  if (!session) return null;

  if (session.expires_at < Date.now()) {
    deleteSessionStmt.run(sessionId);
    return null;
  }

  return session;
}

export function destroyUserSession(sessionId) {
  if (!sessionId) return;
  deleteSessionStmt.run(sessionId);
}
