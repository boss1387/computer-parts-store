import http from "node:http";
import crypto from "node:crypto";
import { URL } from "node:url";

import { parseCookies, setCookie, sendJson, serveStatic } from "./src/http-helpers.js";
import { getSession } from "./src/sessions.js";
import { getUserSession } from "./src/user-sessions.js";
import { handleLogin, handleLogout, handleMe } from "./src/routes/auth.js";
import {
  handleRegister,
  handleAccountLogin,
  handleAccountLogout,
  handleAccountMe,
} from "./src/routes/account.js";
import {
  handleGetProducts,
  handleGetProduct,
  handleCreateProduct,
  handleUpdateProduct,
  handleDeleteProduct,
} from "./src/routes/products.js";
import { handleUploadImage } from "./src/routes/uploads.js";
import { handleGetSuggestions, handleSearch, handleGetRecommendations } from "./src/routes/search.js";

const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === "production";

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return getSession(cookies.session_id);
}

// session ادمین رو با session کاربر عادی قاطی نکن؛ این دوتا کاملاً جدا از همن
function getCustomerSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return getUserSession(cookies.customer_session);
}

// یه شناسه‌ی ناشناس برای هر مرورگر که وارد نشده، تا سرچ‌هاش هم قابل پیشنهاد بمونن
function getOrCreateVisitorId(req, res) {
  const cookies = parseCookies(req);
  if (cookies.visitor_id) return cookies.visitor_id;

  const visitorId = crypto.randomBytes(16).toString("hex");
  setCookie(res, "visitor_id", visitorId, {
    maxAge: 1000 * 60 * 60 * 24 * 365,
    secure: isProd,
    sameSite: "Strict",
  });

  return visitorId;
}

// صاحب تاریخچه‌ی سرچ رو مشخص می‌کنه: اول اکانت لاگین‌شده، وگرنه شناسه‌ی ناشناس مرورگر
function getSearchOwner(req, res) {
  const customerSession = getCustomerSessionFromRequest(req);
  return {
    userId: customerSession ? customerSession.user_id : null,
    visitorId: getOrCreateVisitorId(req, res),
  };
}

// برای درخواست‌هایی که داده رو تغییر میدن (POST/PUT/DELETE) هم باید لاگین باشه، هم CSRF token درست باشه
function requireAdmin(req, res) {
  const session = getSessionFromRequest(req);

  if (!session) {
    sendJson(res, 401, { ok: false, error: "برای این عملیات باید وارد بشی" });
    return null;
  }

  const csrfHeader = req.headers["x-csrf-token"];
  if (!csrfHeader || csrfHeader !== session.csrf_token) {
    sendJson(res, 403, { ok: false, error: "درخواست نامعتبر (CSRF)" });
    return null;
  }

  return session;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;
  const method = req.method;

  // --- Security headers پایه ---
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer-when-downgrade");

  try {
    // ---------- Auth API ----------
    if (pathname === "/api/login" && method === "POST") {
      return await handleLogin(req, res);
    }

    if (pathname === "/api/logout" && method === "POST") {
      return await handleLogout(req, res);
    }

    if (pathname === "/api/me" && method === "GET") {
      const session = getSessionFromRequest(req);
      return await handleMe(req, res, session);
    }

    // ---------- Account API (کاربر عادی / مشتری) ----------
    if (pathname === "/api/account/register" && method === "POST") {
      return await handleRegister(req, res);
    }

    if (pathname === "/api/account/login" && method === "POST") {
      return await handleAccountLogin(req, res);
    }

    if (pathname === "/api/account/logout" && method === "POST") {
      return await handleAccountLogout(req, res);
    }

    if (pathname === "/api/account/me" && method === "GET") {
      const session = getCustomerSessionFromRequest(req);
      return await handleAccountMe(req, res, session);
    }

    // ---------- Search API ----------
    if (pathname === "/api/search/suggestions" && method === "GET") {
      const owner = getSearchOwner(req, res);
      return handleGetSuggestions(req, res, url.searchParams, owner);
    }

    if (pathname === "/api/search" && method === "GET") {
      const owner = getSearchOwner(req, res);
      return handleSearch(req, res, url.searchParams, owner);
    }

    if (pathname === "/api/recommendations" && method === "GET") {
      const owner = getSearchOwner(req, res);
      return handleGetRecommendations(req, res, owner);
    }

    // ---------- Products API ----------
    if (pathname === "/api/products" && method === "GET") {
      return handleGetProducts(req, res, url.searchParams);
    }

    if (pathname === "/api/products" && method === "POST") {
      if (!requireAdmin(req, res)) return;
      return await handleCreateProduct(req, res);
    }

    // ---------- آپلود عکس ----------
    // بدنه‌ی درخواست خود بایت‌های عکسه؛ هر درخواست یک عکس.
    if (pathname === "/api/uploads" && method === "POST") {
      if (!requireAdmin(req, res)) return;
      return await handleUploadImage(req, res);
    }

    const productIdMatch = pathname.match(/^\/api\/products\/(\d+)$/);
    if (productIdMatch) {
      const id = Number(productIdMatch[1]);

      if (method === "GET") {
        return handleGetProduct(req, res, id);
      }

      if (method === "PUT") {
        if (!requireAdmin(req, res)) return;
        return await handleUpdateProduct(req, res, id);
      }

      if (method === "DELETE") {
        if (!requireAdmin(req, res)) return;
        return handleDeleteProduct(req, res, id);
      }
    }

    if (pathname === "/api/categories" && method === "GET") {
      const categories = (await import("./config/categories.json", { with: { type: "json" } }))
        .default;
      return sendJson(res, 200, { ok: true, categories });
    }

    // ---------- فایل‌های استاتیک (صفحات سایت) ----------
    if (method === "GET" || method === "HEAD") {
      const served = serveStatic(req, res, pathname === "/" ? "/pages/home.html" : pathname);
      if (served) return;
    }

    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("404 - یافت نشد");
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { ok: false, error: "خطای داخلی سرور" });
  }
});

server.listen(PORT, () => {
  console.log(`✅ سرور روی http://localhost:${PORT} در حال اجراست`);
});
