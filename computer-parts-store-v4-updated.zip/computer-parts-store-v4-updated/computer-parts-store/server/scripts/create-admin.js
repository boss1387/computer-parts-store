// ساخت یا ریست رمز اکانت ادمین.
//
// روش ۱ (تعاملی - وقتی مستقیم توی ترمینال اجرا می‌کنی):
//   npm run create-admin
//
// روش ۲ (غیرتعاملی - برای اسکریپت/دیپلوی):
//   node scripts/create-admin.js --email=admin@techzone.com --password=SomeStrongPass123

import readline from "node:readline/promises";
import { stdin, stdout } from "node:process";
import db from "../src/db.js";
import { hashPassword, isStrongPassword } from "../src/auth.js";

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function parseArgs() {
  const args = {};
  for (const arg of process.argv.slice(2)) {
    const match = arg.match(/^--(\w+)=(.*)$/);
    if (match) args[match[1]] = match[2];
  }
  return args;
}

async function getCredentials() {
  const args = parseArgs();

  if (args.email && args.password) {
    return { email: args.email, password: args.password };
  }

  if (!stdin.isTTY) {
    console.error(
      "❌ این محیط تعاملی نیست. از این شکل استفاده کن:\n" +
        "   node scripts/create-admin.js --email=admin@example.com --password=SomeStrongPass123"
    );
    process.exit(1);
  }

  const rl = readline.createInterface({ input: stdin, output: stdout });
  const email = await rl.question("ایمیل ادمین: ");
  const password = await rl.question("رمز عبور ادمین (حداقل ۸ کاراکتر): ");
  const confirmPassword = await rl.question("تکرار رمز عبور: ");
  rl.close();

  if (password !== confirmPassword) {
    console.error("❌ رمزهای واردشده یکسان نیستن.");
    process.exit(1);
  }

  return { email, password };
}

async function main() {
  const { email: rawEmail, password } = await getCredentials();
  const email = rawEmail.trim().toLowerCase();

  if (!isValidEmail(email)) {
    console.error("❌ ایمیل معتبر نیست.");
    process.exit(1);
  }

  if (!isStrongPassword(password)) {
    console.error("❌ رمز عبور باید حداقل ۸ کاراکتر باشه.");
    process.exit(1);
  }

  const passwordHash = hashPassword(password);
  const existing = db.prepare("SELECT id FROM admins WHERE email = ?").get(email);

  if (existing) {
    db.prepare("UPDATE admins SET password_hash = ? WHERE email = ?").run(passwordHash, email);
    console.log(`✅ رمز عبور ادمین «${email}» به‌روزرسانی شد.`);
  } else {
    db.prepare("INSERT INTO admins (email, password_hash) VALUES (?, ?)").run(
      email,
      passwordHash
    );
    console.log(`✅ اکانت ادمین «${email}» ساخته شد.`);
  }

  process.exit(0);
}

main().catch((err) => {
  console.error("خطا:", err);
  process.exit(1);
});
